# 🛡️ AG Mode Manager

> **Cross-Platform AntiGravity Mode, Rules, Knowledge & Quality-Control System**  
> *Operate Google AntiGravity with specialized rules, domain workflows, quality gates, and architectural intelligence.*

---

## 📌 Important Notice: Safe Integration
**AG Mode Manager DOES NOT replace, modify, or patch AntiGravity's core executables, internal Electron application files, conversation transcripts, or databases.**

Instead, AG Mode Manager integrates using AntiGravity's **officially supported hierarchical workspace customization mechanisms**:
- Project Rules: `<workspace>/.agents/rules/*.md`
- Root Instruction Markers: `<workspace>/GEMINI.md`
- On-Demand Interactive Skills: `<workspace>/.agents/skills/ag-mode/SKILL.md`
- Isolated User Application Data: `~/.ag-mode-manager/`

AntiGravity remains 100% independent, uncorrupted, and fully usable on its own.

---

## 🚀 Key Features

- **Intuitive TUI & CLI**:
  - Simple Category-first terminal navigation (`Development`, `Data & AI`, `Cybersecurity`, `Engineering`, `Academic`, `Languages`, `General`).
  - Dynamic live search by keywords, frameworks, or tags.
  - Interactive confirmation dialogs (`[ Yes ]` / `[ No ]`).
  - Full keyboard (`↑`/`↓`/`Enter`/`Esc`/`Tab`) and mouse selection support.
- **70+ Specialized Working Modes**:
  - Web Development, Android, iOS, Data Science, Machine Learning, Deep Learning, Cybersecurity, Ethical Hacking, Digital Logic, Networks, Windows, Linux, Mathematics, Islamic Knowledge (Strict Source Control), and more.
- **Deep Modular Knowledge**:
  - Modes are NOT single giant prompts. Each mode contains connected markdown files (`core.md`, `architecture.md`, `tools.md`, `quality-gate.md`, `ui-ux.md`, `security.md`).
- **Web Project Intelligence**:
  - Website type detection (E-commerce, LMS, Library Management, Hospital Management, SaaS, Portfolio, Dashboard).
  - UI/UX Design Engine (Material, Fluent, HIG, Minimalism, Modern SaaS).
  - Anti "AI-Generated Website" rules (no random purple/blue gradients everywhere, no emoji logos, no fake statistics).
  - Authentic vector SVG brand logo requirements.
- **Multi-Mode Composition**:
  - Activate mode combinations (e.g. `WEB + CYBERSECURITY` or `DATA SCIENCE + MACHINE LEARNING`).
  - Automatic dependency resolution and quality-gate merging.
- **DevSecOps & Zero Secret Leaks**:
  - Built-in secret scrubber redacting API keys (Gemini, OpenAI, Anthropic, AWS, GitHub), tokens, passwords, and connection strings from logs.
- **Atomic Backup & Rollback**:
  - Automatic SHA-256 snapshots before any workspace file modification.
  - Instant one-command rollback to previous state.
- **Non-Destructive Repair & Safe Uninstall**:
  - Validates and restores damaged files without deleting user projects.
  - Complete uninstall restores workspace to pristine condition and leaves AntiGravity untouched.

---

## 💻 Supported Platforms & Architectures

| Platform | Supported Architectures | Tested / Verified |
| :--- | :--- | :--- |
| **Windows** (10 / 11 / Server) | x64, ARM64 | **Verified** |
| **Linux** (Ubuntu, Debian, Fedora, Arch) | x64 (amd64), ARM64 | **Verified** |
| **macOS** (12+ Monterey, Ventura, Sonoma, Sequoia) | Apple Silicon (ARM64), Intel (x64) | **Verified** |

---

## 📦 Installation

### Windows (PowerShell)
Open PowerShell in the `ag-mode-manager` directory:
```powershell
.\installers\install.ps1
```
Or install in Python environment:
```powershell
pip install -e .
```

### Linux & macOS
Run the shell installer:
```bash
chmod +x installers/install.sh
./installers/install.sh
```
Or install via pip:
```bash
pip install -e .
```

---

## 🎮 How to Use

### 1. Launch Interactive Terminal UI (TUI)
Simply run `ag-mode` (or `agmm`):
```bash
ag-mode
```
**Workflow**:
1. Select a Category (`Development`, `Data & AI`, etc.)
2. Select a Mode (e.g. `Web Development`)
3. Review Confirmation Popup (`[ YES ]  [ NO ]`)
4. Confirm: AG Mode Manager activates the mode, compiles rules, and connects to AntiGravity.
5. AntiGravity opens or continues with the selected mode active!

### 2. Command Line Interface (CLI)
AG Mode Manager can also be automated or scripted directly from your shell:

```bash
# Show status of current workspace
ag-mode status

# List all categories and modes
ag-mode list

# Search modes by keyword
ag-mode search python
ag-mode search security

# Activate a mode in current workspace
ag-mode activate web

# Activate in a specific target workspace
ag-mode activate android --workspace C:\Projects\MyMobileApp

# Compose multiple modes
ag-mode compose web cybersecurity

# Activate composed modes
ag-mode activate web --compose cybersecurity

# Deactivate active mode (clean workspace)
ag-mode deactivate

# Rollback to previous configuration snapshot
ag-mode rollback

# Repair application and validate registry
ag-mode repair

# View sanitized diagnostic logs
ag-mode logs --type activation

# Create a custom mode
ag-mode custom create "UET Robotics" --desc "University robotics workflow" --category "Computer & Engineering"
```

---

## 📂 Project Structure

```
ag-mode-manager/
├── src/
│   └── ag_mode/
│       ├── config.py             # Config & workspace detection
│       ├── core/
│       │   ├── registry.py       # Dynamic mode registry & metadata
│       │   ├── resolver.py       # Dependency DAG resolution
│       │   ├── composer.py       # Multi-mode composition & conflict handling
│       │   ├── context.py        # Project inspector & website type detection
│       │   └── custom_mode.py    # Custom mode creation & management
│       ├── integration/
│       │   ├── detector.py       # AntiGravity environment detector
│       │   ├── adapter.py        # Safe .agents/ rules & GEMINI.md generator
│       │   └── backup.py         # Atomic SHA-256 backup & rollback engine
│       ├── tui/
│       │   └── app.py            # Prompt_toolkit + Rich interactive TUI
│       ├── cli/
│       │   └── main.py           # CLI parser & subcommand handlers
│       ├── security/
│       │   └── sanitizer.py      # Secret scrubber & path safety validator
│       ├── diagnostics/
│       │   └── logger.py         # Sanitized structured logging
│       ├── platform/
│       │   └── detector.py       # OS, architecture & terminal detector
│       └── installer/
│           ├── installer.py      # Cross-platform installation engine
│           ├── repair.py         # Non-destructive repair engine
│           └── uninstaller.py    # Safe uninstallation engine
├── modes/                        # 70+ built-in modular mode definitions
│   ├── web/
│   ├── android/
│   ├── ios/
│   ├── data-science/
│   ├── machine-learning/
│   ├── cybersecurity/
│   ├── ethical-hacking/
│   ├── islamic-knowledge/
│   ├── modes.json                # Central mode registry index
│   └── ...
├── installers/
│   ├── install.ps1               # Windows PowerShell installer
│   ├── install.sh                # Linux/macOS installer
│   └── ag-mode.bat               # Windows batch launcher
├── tests/                        # Automated unit and integration test suite
├── docs/                         # In-depth architectural & integration guides
├── setup.py                      # Package installation script
└── README.md
```

---

## 🔒 Security & Privacy Guarantees
- **No Plaintext Secrets in Logs**: Sensitive API keys (`AIza...`, `sk-...`, `ghp_...`, `AKIA...`), JWT bearer tokens, and connection passwords are automatically replaced with `[REDACTED]` before writing to disk.
- **Path Traversal Protection**: System directories (`System32`, `/etc/shadow`) cannot be targeted.
- **Zero Data Loss Guarantee**: Uninstalling or resetting AG Mode Manager will NEVER delete user projects, AntiGravity chat conversations, history, or transcripts.

---

## 🧪 Automated Testing
Run the complete automated test suite:
```bash
python -m unittest discover tests
```
The suite verifies:
- Mode registry integrity and 70+ mode discovery
- Dependency resolution, topological sorting, and cycle avoidance
- Multi-mode composition and quality gate merging
- Secret scrubbing and credential protection
- Workspace activation, mode switching, and bit-for-bit rollback
- Corrupted configuration recovery and repair
- Safe uninstallation preserving user code and AntiGravity data

---

## 📄 License
MIT License. Free and open source for all developers and teams.
