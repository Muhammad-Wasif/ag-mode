#!/usr/bin/env bash
set -e
INSTALL_DIR="$HOME/.ag-mode-manager"
BIN_DIR="$INSTALL_DIR/bin"
mkdir -p "$INSTALL_DIR" "$BIN_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR/src" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/modes" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/docs" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/README.md" "$INSTALL_DIR/" 2>/dev/null || true

cat << 'EOF' > "$BIN_DIR/ag-mode"
#!/usr/bin/env bash
export PYTHONPATH="$HOME/.ag-mode-manager/src:$PYTHONPATH"
exec python3 -m ag_mode.cli.main "$@"
EOF
chmod +x "$BIN_DIR/ag-mode"
ln -sf "$BIN_DIR/ag-mode" "$BIN_DIR/ag"

cat << 'EOF' > "$BIN_DIR/launch-antigravity"
#!/usr/bin/env bash
export PYTHONPATH="$HOME/.ag-mode-manager/src:$PYTHONPATH"
python3 -m ag_mode.cli.launcher "$@"
EOF
chmod +x "$BIN_DIR/launch-antigravity"

for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [ -f "$rc" ] && ! grep -q ".ag-mode-manager/bin" "$rc"; then
        echo 'export PATH="$HOME/.ag-mode-manager/bin:$PATH"' >> "$rc"
    fi
done

python3 -m pip install --quiet --user rich prompt_toolkit 2>/dev/null || true
export PYTHONPATH="$INSTALL_DIR/src:$PYTHONPATH"
python3 -m ag_mode.installer.installer >/dev/null 2>&1 || true

echo "AG Mode Manager installed successfully to $INSTALL_DIR!"
echo "Commands 'ag' and 'launch-antigravity' are available in PATH."
